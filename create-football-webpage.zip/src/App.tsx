import { useState, useEffect } from 'react';
import { Trophy, Users, Shield, Gamepad2, ArrowRight, Zap, Target, Clock, Star, Award, ArrowLeft, Settings, RefreshCw, AlertCircle } from 'lucide-react';
import axios from 'axios';

interface League {
  id: number;
  name: string;
  country: string;
  flag: string;
  apiId?: number;
}

interface Team {
  id: number;
  name: string;
  shortName: string;
  logo: string;
  league: string;
  founded: number;
  stadium: string;
  manager: string;
  titles: number;
  value: string;
  color: string;
  apiId?: number;
}

interface Player {
  id: number;
  name: string;
  position: string;
  number: number;
  nationality: string;
  age: number;
  photo: string;
  team: string;
  league: string;
  goals: number;
  assists: number;
  appearances: number;
  rating: number;
  value: string;
  joined: number;
  bio: string;
  stats: {
    speed: number;
    shooting: number;
    passing: number;
    dribbling: number;
    defending: number;
    physical: number;
  };
}

const leaguesData: League[] = [
  { id: 1, name: 'La Liga', country: 'España', flag: '🇪🇸', apiId: 140 },
  { id: 2, name: 'Premier League', country: 'Inglaterra', flag: '🏴󠁧󠁢󠁥󠁮󠁧󠁿', apiId: 39 },
  { id: 3, name: 'Bundesliga', country: 'Alemania', flag: '🇩🇪', apiId: 78 },
  { id: 4, name: 'Serie A', country: 'Italia', flag: '🇮🇹', apiId: 135 },
  { id: 5, name: 'Ligue 1', country: 'Francia', flag: '🇫🇷', apiId: 61 },
];

const mockTeamsData: Team[] = [
  { id: 1, name: 'Real Madrid CF', shortName: 'Real Madrid', logo: '⚪', league: 'La Liga', founded: 1902, stadium: 'Santiago Bernabéu', manager: 'Carlo Ancelotti', titles: 36, value: '€1.45B', color: 'white', apiId: 541 },
  { id: 2, name: 'FC Barcelona', shortName: 'Barcelona', logo: '🔴🔵', league: 'La Liga', founded: 1899, stadium: 'Camp Nou', manager: 'Hansi Flick', titles: 27, value: '€1.12B', color: 'blue', apiId: 529 },
  { id: 4, name: 'Manchester City', shortName: 'Man City', logo: '🔵', league: 'Premier League', founded: 1880, stadium: 'Etihad Stadium', manager: 'Pep Guardiola', titles: 10, value: '€1.35B', color: 'blue', apiId: 50 },
  { id: 5, name: 'Liverpool FC', shortName: 'Liverpool', logo: '🔴', league: 'Premier League', founded: 1892, stadium: 'Anfield', manager: 'Arne Slot', titles: 19, value: '€950M', color: 'red', apiId: 40 },
  { id: 7, name: 'Bayern Munich', shortName: 'Bayern', logo: '🔴⚪', league: 'Bundesliga', founded: 1900, stadium: 'Allianz Arena', manager: 'Vincent Kompany', titles: 33, value: '€980M', color: 'red', apiId: 157 },
];

const mockPlayersData: Player[] = [
  { id: 1, name: "Kylian Mbappé", position: "Delantero", number: 9, nationality: "Francia", age: 26, photo: "https://media.api-sports.io/football/players/149.png", team: "Real Madrid CF", league: "La Liga", goals: 17, assists: 6, appearances: 15, rating: 9.1, value: "€160M", joined: 2024, bio: "Campeón del Mundo 2018. Uno de los delanteros más letales del planeta.", stats: { speed: 97, shooting: 89, passing: 82, dribbling: 94, defending: 38, physical: 82 } },
  { id: 2, name: "Vinícius Júnior", position: "Extremo", number: 7, nationality: "Brasil", age: 24, photo: "https://media.api-sports.io/football/players/322.png", team: "Real Madrid CF", league: "La Liga", goals: 13, assists: 11, appearances: 16, rating: 8.9, value: "€150M", joined: 2018, bio: "Balón de Oro 2024. Considerado el mejor jugador del mundo actualmente.", stats: { speed: 96, shooting: 85, passing: 84, dribbling: 96, defending: 45, physical: 78 } },
  { id: 3, name: "Erling Haaland", position: "Delantero", number: 9, nationality: "Noruega", age: 24, photo: "https://media.api-sports.io/football/players/826.png", team: "Manchester City", league: "Premier League", goals: 19, assists: 4, appearances: 14, rating: 9.3, value: "€180M", joined: 2022, bio: "Máquina de hacer goles. Récord tras récord en la Premier League.", stats: { speed: 89, shooting: 96, passing: 74, dribbling: 82, defending: 48, physical: 91 } },
];

export function App() {
  const [currentTab, setCurrentTab] = useState<'home' | 'leagues' | 'players' | 'minigames' | 'api'>('home');
  const [selectedLeague, setSelectedLeague] = useState<League | null>(null);
  const [selectedTeam, setSelectedTeam] = useState<Team | null>(null);
  const [selectedPlayer, setSelectedPlayer] = useState<Player | null>(null);
  
  const [teams, setTeams] = useState<Team[]>(mockTeamsData);
  const [players, setPlayers] = useState<Player[]>(mockPlayersData);
  const [liveMatches, setLiveMatches] = useState<any[]>([
    { id: 1, homeTeam: 'Real Madrid', awayTeam: 'Barcelona', homeScore: 2, awayScore: 1, time: "67'", league: 'La Liga', isLive: true },
    { id: 2, homeTeam: 'Man City', awayTeam: 'Liverpool', homeScore: 1, awayScore: 2, time: "42'", league: 'Premier League', isLive: true },
  ]);

  const [apiKey, setApiKey] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);
  const [apiStatus, setApiStatus] = useState<'idle' | 'connected' | 'error'>('idle');
  const [error, setError] = useState('');

  const [currentMiniGame, setCurrentMiniGame] = useState<'penalty' | 'guess' | 'freekick'>('penalty');
  const [penaltyScore, setPenaltyScore] = useState(0);
  const [penaltyShots, setPenaltyShots] = useState(0);
  const [isShooting, setIsShooting] = useState(false);
  const [shotResult, setShotResult] = useState('');
  const [guessScore, setGuessScore] = useState(0);

  // Simulate live updates
  useEffect(() => {
    const interval = setInterval(() => {
      setLiveMatches(prev => prev.map(match => {
        if (Math.random() > 0.6 && match.isLive) {
          const isHome = Math.random() > 0.5;
          return {
            ...match,
            homeScore: isHome ? match.homeScore + (Math.random() > 0.7 ? 1 : 0) : match.homeScore,
            awayScore: !isHome ? match.awayScore + (Math.random() > 0.7 ? 1 : 0) : match.awayScore,
            time: `${parseInt(match.time) + 1}'`
          };
        }
        return match;
      }));
    }, 6000);
    return () => clearInterval(interval);
  }, []);

  const fetchFromAPI = async (endpoint: string) => {
    if (!apiKey) return null;
    
    try {
      const response = await axios.get(`https://v3.football.api-sports.io/${endpoint}`, {
        headers: {
          'x-apisports-key': apiKey
        }
      });
      return response.data;
    } catch (err) {
      console.error(err);
      return null;
    }
  };

  const connectToAPI = async () => {
    if (!apiKey) {
      setError('Por favor ingresa una API Key');
      return;
    }

    setIsLoading(true);
    setError('');

    try {
      const data = await fetchFromAPI('leagues');
      if (data && data.response && data.response.length > 0) {
        setApiStatus('connected');
        alert('¡Conectado exitosamente a API-Football!');
        
        // Load some real teams for La Liga
        const teamsData = await fetchFromAPI('teams?league=140&season=2024');
        if (teamsData?.response) {
          const realTeams = teamsData.response.slice(0, 8).map((t: any, i: number) => ({
            id: 100 + i,
            name: t.team.name,
            shortName: t.team.name.length > 15 ? t.team.name.substring(0, 12) : t.team.name,
            logo: t.team.logo,
            league: 'La Liga',
            founded: t.team.founded || 1900,
            stadium: t.venue?.name || 'Estadio Desconocido',
            manager: 'Desconocido',
            titles: Math.floor(Math.random() * 15) + 1,
            value: `€${(Math.random() * 800 + 200).toFixed(0)}M`,
            color: ['white', 'blue', 'red'][Math.floor(Math.random()*3)],
            apiId: t.team.id
          }));
          setTeams([...mockTeamsData, ...realTeams]);
        }
      } else {
        setApiStatus('error');
        setError('API Key inválida o sin permisos');
      }
    } catch (err) {
      setApiStatus('error');
      setError('Error al conectar con la API');
    } finally {
      setIsLoading(false);
    }
  };

  const getPlayersByTeam = (teamName: string) => {
    return players.filter(p => p.team === teamName || p.team.includes(teamName));
  };

  const shootPenalty = (direction: string) => {
    if (isShooting) return;
    
    setIsShooting(true);
    const random = Math.random();
    let result = '';
    let points = 0;
    
    if (random < 0.75) {
      result = '¡GOLAZO! ⚽';
      points = 1;
    } else if (random < 0.9) {
      result = '¡PARADA DEL PORTERO!';
    } else {
      result = '¡FUERA!';
    }
    
    setShotResult(result);
    
    setTimeout(() => {
      if (points === 1) setPenaltyScore(prev => prev + 1);
      setPenaltyShots(prev => prev + 1);
      setShotResult('');
      setIsShooting(false);
      
      if (penaltyShots >= 4) {
        setTimeout(() => {
          alert(`¡Partido terminado! Marcaste ${penaltyScore + (points === 1 ? 1 : 0)} de 5 penales.`);
          setPenaltyScore(0);
          setPenaltyShots(0);
        }, 800);
      }
    }, 1300);
  };

  const guessPlayer = (correct: boolean) => {
    if (correct) {
      setGuessScore(prev => prev + 20);
      alert("¡Correcto! +20 puntos");
    } else {
      alert("Incorrecto. Era Kylian Mbappé");
    }
  };

  const resetNavigation = () => {
    setSelectedLeague(null);
    setSelectedTeam(null);
    setSelectedPlayer(null);
  };

  return (
    <div className="min-h-screen bg-zinc-950 text-white">
      {/* NAVBAR */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-zinc-950/95 backdrop-blur-xl border-b border-zinc-800">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 bg-gradient-to-br from-emerald-500 to-teal-400 rounded-2xl flex items-center justify-center text-4xl shadow-xl shadow-emerald-500/30">
              ⚽
            </div>
            <div>
              <div className="font-black text-4xl tracking-[-3px]">FULLFUTBOL</div>
              <div className="text-xs text-emerald-400 font-mono -mt-1">DATOS EN TIEMPO REAL</div>
            </div>
          </div>

          <div className="flex items-center gap-2 bg-zinc-900 rounded-3xl p-1 border border-zinc-800">
            {[
              { id: 'home', label: 'Inicio', icon: Trophy },
              { id: 'leagues', label: 'Ligas', icon: Shield },
              { id: 'players', label: 'Jugadores', icon: Users },
              { id: 'minigames', label: 'Minijuegos', icon: Gamepad2 },
              { id: 'api', label: 'APIs', icon: Settings },
            ].map((tab) => {
              const Icon = tab.icon;
              const isActive = currentTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => {
                    setCurrentTab(tab.id as any);
                    if (tab.id !== 'leagues') resetNavigation();
                  }}
                  className={`flex items-center gap-2 px-6 py-2.5 rounded-3xl text-sm font-medium transition-all ${
                    isActive 
                      ? 'bg-emerald-500 text-black shadow-lg shadow-emerald-500/30' 
                      : 'hover:bg-zinc-800'
                  }`}
                >
                  <Icon size={18} />
                  {tab.label}
                </button>
              );
            })}
          </div>
        </div>
      </nav>

      <div className="pt-24 pb-12 max-w-7xl mx-auto px-6">
        {/* HOME */}
        {currentTab === 'home' && (
          <div>
            <div className="text-center mb-12">
              <h1 className="text-7xl font-black mb-4 tracking-tighter">FULLFUTBOL</h1>
              <p className="text-2xl text-zinc-400">El fútbol en tiempo real</p>
            </div>

            {/* LIVE MATCHES */}
            <div className="mb-12">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-4 h-4 bg-red-500 rounded-full animate-pulse"></div>
                <h2 className="text-3xl font-bold">Partidos en Vivo</h2>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {liveMatches.map(match => (
                  <div key={match.id} className="bg-zinc-900 rounded-3xl p-8 border border-red-500/20">
                    <div className="text-red-500 text-sm font-mono mb-4 flex items-center gap-2">
                      <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
                      EN VIVO • {match.time}
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <div className="text-center flex-1">
                        <div className="text-4xl mb-2">{match.homeTeam}</div>
                        <div className="text-6xl font-bold text-emerald-400">{match.homeScore}</div>
                      </div>
                      <div className="text-5xl text-zinc-700 mx-6">VS</div>
                      <div className="text-center flex-1">
                        <div className="text-4xl mb-2">{match.awayTeam}</div>
                        <div className="text-6xl font-bold text-emerald-400">{match.awayScore}</div>
                      </div>
                    </div>
                    <div className="text-center text-xs text-zinc-500 mt-6">{match.league}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* LIGAS */}
        {currentTab === 'leagues' && !selectedLeague && (
          <div>
            <h2 className="text-4xl font-bold mb-8">Ligas Principales</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {leaguesData.map(league => (
                <div 
                  key={league.id}
                  onClick={() => setSelectedLeague(league)}
                  className="bg-zinc-900 hover:bg-zinc-800 transition-all rounded-3xl p-8 cursor-pointer border border-zinc-700 hover:border-emerald-500 group"
                >
                  <div className="text-6xl mb-6">{league.flag}</div>
                  <h3 className="text-3xl font-bold mb-1">{league.name}</h3>
                  <p className="text-zinc-400">{league.country}</p>
                  <div className="mt-8 text-emerald-400 flex items-center gap-2 text-sm font-medium">
                    VER EQUIPOS <ArrowRight className="group-hover:translate-x-1 transition" />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* EQUIPOS DE UNA LIGA */}
        {selectedLeague && !selectedTeam && (
          <div>
            <button 
              onClick={() => setSelectedLeague(null)}
              className="flex items-center gap-2 text-zinc-400 hover:text-white mb-8"
            >
              <ArrowLeft /> Volver a Ligas
            </button>
            
            <h2 className="text-4xl font-bold mb-2">{selectedLeague.name}</h2>
            <p className="text-zinc-400 mb-10">Selecciona un equipo</p>

            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {teams
                .filter(t => t.league === selectedLeague.name)
                .map(team => (
                  <div 
                    key={team.id}
                    onClick={() => setSelectedTeam(team)}
                    className="bg-zinc-900 rounded-3xl p-6 hover:bg-zinc-800 cursor-pointer transition-all hover:scale-105 border border-transparent hover:border-white/20"
                  >
                    <div className="text-6xl mb-4 text-center">{team.logo}</div>
                    <div className="font-bold text-xl text-center">{team.shortName}</div>
                    <div className="text-center text-xs text-zinc-500 mt-1">{team.stadium}</div>
                  </div>
                ))}
            </div>
          </div>
        )}

        {/* JUGADORES DE UN EQUIPO */}
        {selectedTeam && !selectedPlayer && (
          <div>
            <button 
              onClick={() => setSelectedTeam(null)}
              className="flex items-center gap-2 text-zinc-400 hover:text-white mb-6"
            >
              <ArrowLeft /> Volver a Equipos
            </button>

            <div className="flex items-center gap-6 mb-10">
              <div className="text-7xl">{selectedTeam.logo}</div>
              <div>
                <h2 className="text-5xl font-bold">{selectedTeam.name}</h2>
                <p className="text-zinc-400">Fundado en {selectedTeam.founded} • {selectedTeam.stadium}</p>
              </div>
            </div>

            <h3 className="text-2xl font-semibold mb-6">Plantilla</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {getPlayersByTeam(selectedTeam.name).map(player => (
                <div 
                  key={player.id}
                  onClick={() => setSelectedPlayer(player)}
                  className="bg-zinc-900 p-6 rounded-3xl hover:bg-zinc-800 cursor-pointer transition-all flex gap-5 items-center border border-white/5 hover:border-emerald-400"
                >
                  <div className="w-16 h-16 bg-zinc-800 rounded-2xl flex items-center justify-center text-4xl flex-shrink-0">
                    {player.photo.startsWith('http') ? '👤' : player.photo}
                  </div>
                  <div>
                    <div className="font-bold text-xl">{player.name}</div>
                    <div className="text-emerald-400 text-sm">{player.position} • #{player.number}</div>
                    <div className="text-xs text-zinc-500 mt-1">{player.nationality} • {player.age} años</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ESTADÍSTICAS DEL JUGADOR */}
        {selectedPlayer && (
          <div>
            <button 
              onClick={() => setSelectedPlayer(null)}
              className="flex items-center gap-2 text-zinc-400 hover:text-white mb-8"
            >
              <ArrowLeft /> Volver a Plantilla
            </button>

            <div className="bg-zinc-900 rounded-3xl p-12 max-w-4xl mx-auto">
              <div className="flex flex-col md:flex-row gap-12 items-center">
                <div className="text-[180px] flex-shrink-0">{selectedPlayer.photo.startsWith('http') ? '🏆' : selectedPlayer.photo}</div>
                
                <div className="flex-1">
                  <div className="uppercase tracking-[3px] text-emerald-400 text-sm mb-2">{selectedPlayer.nationality}</div>
                  <h1 className="text-6xl font-black mb-2">{selectedPlayer.name}</h1>
                  <div className="text-2xl text-zinc-400 mb-8">{selectedPlayer.position} • {selectedPlayer.team}</div>

                  <div className="grid grid-cols-3 gap-8 mb-10">
                    <div>
                      <div className="text-4xl font-bold text-emerald-400">{selectedPlayer.goals}</div>
                      <div className="text-xs uppercase tracking-widest text-zinc-500">Goles</div>
                    </div>
                    <div>
                      <div className="text-4xl font-bold text-emerald-400">{selectedPlayer.assists}</div>
                      <div className="text-xs uppercase tracking-widest text-zinc-500">Asistencias</div>
                    </div>
                    <div>
                      <div className="text-4xl font-bold text-emerald-400">{selectedPlayer.rating}</div>
                      <div className="text-xs uppercase tracking-widest text-zinc-500">RATING</div>
                    </div>
                  </div>

                  <p className="text-zinc-400 leading-relaxed mb-8">{selectedPlayer.bio}</p>

                  <h4 className="font-semibold mb-4 text-lg">HABILIDADES</h4>
                  <div className="space-y-6">
                    {Object.entries(selectedPlayer.stats).map(([key, value]) => (
                      <div key={key}>
                        <div className="flex justify-between text-sm mb-1.5">
                          <span className="capitalize">{key}</span>
                          <span className="font-mono text-emerald-400">{value}</span>
                        </div>
                        <div className="h-2.5 bg-zinc-800 rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-gradient-to-r from-emerald-400 to-teal-400 rounded-full transition-all"
                            style={{ width: `${value}%` }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* MINIJUEGOS */}
        {currentTab === 'minigames' && (
          <div className="max-w-2xl mx-auto">
            <h2 className="text-5xl font-bold text-center mb-12">Minijuegos</h2>
            
            <div className="flex justify-center gap-4 mb-10">
              {[
                { id: 'penalty', label: 'Penales', emoji: '🥅' },
                { id: 'guess', label: 'Adivina', emoji: '🧠' },
                { id: 'freekick', label: 'Tiro Libre', emoji: '⚽' },
              ].map(game => (
                <button
                  key={game.id}
                  onClick={() => setCurrentMiniGame(game.id as any)}
                  className={`px-8 py-4 rounded-3xl font-medium transition-all ${
                    currentMiniGame === game.id 
                      ? 'bg-white text-black scale-110' 
                      : 'bg-zinc-900 hover:bg-zinc-800'
                  }`}
                >
                  {game.emoji} {game.label}
                </button>
              ))}
            </div>

            {currentMiniGame === 'penalty' && (
              <div className="bg-zinc-900 rounded-3xl p-12 text-center">
                <h3 className="text-4xl font-bold mb-8">PENALES</h3>
                <div className="text-8xl mb-10">🥅</div>
                
                <div className="grid grid-cols-3 gap-4 max-w-xs mx-auto">
                  {['Izquierda', 'Centro', 'Derecha'].map(dir => (
                    <button
                      key={dir}
                      onClick={() => shootPenalty(dir)}
                      disabled={isShooting}
                      className="bg-emerald-600 hover:bg-emerald-500 disabled:bg-zinc-700 py-8 rounded-2xl font-bold text-lg transition-all active:scale-95"
                    >
                      {dir}
                    </button>
                  ))}
                </div>

                {shotResult && <div className="mt-8 text-4xl font-bold text-yellow-400">{shotResult}</div>}
                
                <div className="mt-12 font-mono text-xl">
                  Goles: <span className="text-emerald-400 font-bold">{penaltyScore}</span> / {penaltyShots}
                </div>
              </div>
            )}

            {currentMiniGame === 'guess' && (
              <div className="bg-zinc-900 rounded-3xl p-16 text-center">
                <div className="text-8xl mb-8">🧠</div>
                <h3 className="text-5xl font-bold mb-8">¿Quién es este jugador?</h3>
                <div className="text-[140px] mx-auto mb-8">⚡</div>
                <div className="text-2xl mb-12">26 años • Delantero • Real Madrid</div>
                
                <div className="grid grid-cols-2 gap-4 max-w-md mx-auto">
                  <button onClick={() => guessPlayer(true)} className="bg-emerald-500 text-black py-6 rounded-3xl font-bold">Kylian Mbappé</button>
                  <button onClick={() => guessPlayer(false)} className="bg-zinc-800 py-6 rounded-3xl font-bold">Erling Haaland</button>
                </div>
                
                <div className="mt-12 text-emerald-400 font-mono">PUNTOS: {guessScore}</div>
              </div>
            )}
          </div>
        )}

        {/* API CONFIG */}
        {currentTab === 'api' && (
          <div className="max-w-2xl mx-auto bg-zinc-900 rounded-3xl p-12">
            <div className="flex items-center gap-4 mb-8">
              <Settings className="w-9 h-9" />
              <h2 className="text-4xl font-bold">Configuración de APIs</h2>
            </div>

            <div className="space-y-8">
              <div>
                <label className="block text-sm text-zinc-400 mb-3">API-Football Key (v3)</label>
                <input
                  type="text"
                  value={apiKey}
                  onChange={(e) => setApiKey(e.target.value)}
                  placeholder="Ingresa tu API Key de api-football.com"
                  className="w-full bg-black border border-zinc-700 rounded-2xl px-6 py-4 text-sm font-mono focus:outline-none focus:border-emerald-500"
                />
                <p className="text-xs text-zinc-500 mt-2">
                  Regístrate gratis en <a href="https://api-football.com" target="_blank" className="text-emerald-400 underline">api-football.com</a>
                </p>
              </div>

              <button
                onClick={connectToAPI}
                disabled={isLoading}
                className="w-full bg-white text-black py-5 rounded-2xl font-bold text-lg hover:bg-emerald-400 transition-all disabled:opacity-50 flex items-center justify-center gap-3"
              >
                {isLoading ? <RefreshCw className="animate-spin" /> : <Zap />}
                {isLoading ? 'CONECTANDO...' : 'CONECTAR A API-FOOTBALL'}
              </button>

              {apiStatus === 'connected' && (
                <div className="bg-emerald-900/30 border border-emerald-500 text-emerald-400 p-6 rounded-2xl flex items-center gap-3">
                  <div className="w-5 h-5 bg-emerald-400 rounded-full"></div>
                  Conectado exitosamente. Datos reales cargados.
                </div>
              )}

              {error && (
                <div className="bg-red-900/30 border border-red-500 text-red-400 p-6 rounded-2xl flex items-center gap-3">
                  <AlertCircle /> {error}
                </div>
              )}

              <div className="text-xs text-zinc-500 leading-relaxed">
                <strong>APIs disponibles:</strong> API-Football, TheSportsDB, Football-Data.org<br/>
                Actualmente usando: <span className="text-emerald-400">API-Football v3</span>
              </div>
            </div>
          </div>
        )}
      </div>

      <footer className="bg-black py-12 text-center text-xs text-zinc-500 border-t border-zinc-900">
        FULLFUTBOL • Integración con APIs de fútbol en tiempo real • 2025
      </footer>
    </div>
  );
}
